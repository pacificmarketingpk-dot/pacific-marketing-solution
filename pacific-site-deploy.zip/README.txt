Pacific Marketing Solution LLC - website files

Upload everything in this folder to a static host (Cloudflare Pages, Netlify, Vercel, GitHub Pages).
index.html is the whole website. The other files only make addresses such as /about and
/services/seo-aeo-geo open correctly when someone types them in or refreshes the page.

  index.html   the website (clean addresses such as /about)
  _redirects   Netlify and Cloudflare Pages: send every address to index.html
  vercel.json  Vercel: the same rule
  404.html     GitHub Pages: the same rule (it has no redirect file)

After the site is live on your domain, still to do:
  - FORM_ENDPOINT   (web-app URL of google-apps-script-forms.gs)  -> forms send email
  - GOOGLE_MAPS_API_KEY (browser key restricted to your domain)   -> interactive map
Both settings are near the top of index.html in clearly marked blocks.
